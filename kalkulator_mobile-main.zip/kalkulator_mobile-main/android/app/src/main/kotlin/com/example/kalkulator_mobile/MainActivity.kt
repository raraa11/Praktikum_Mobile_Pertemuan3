package com.example.kalkulator_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
